package com.example.cookingrecipes

data class Ingredient(
    val name: String,
    val quantity: String
)
